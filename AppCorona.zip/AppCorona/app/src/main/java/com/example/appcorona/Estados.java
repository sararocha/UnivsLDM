package com.example.appcorona;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class Estados extends AppCompatActivity {


    private AlertDialog.Builder dialog;
    private ListView lista;
    private String [] listaEstados = {"Acre", "Alagoas", "Amapá", "Amazonas", "Bahia"," Ceará", "Distrito Federal", "Espirito Santo", "Goiás", "Maranhão", "Mato Grosso", "Mato Grosso do Sul", "Minas Gerais", "Pará", "Paraíba", "Paraná"," Pernambuco", "Piaui", "Rio de Janeiro", "Rio Grande do Norte", "Rio Grande do Sul", "Rondonia", "Roraima", "Santa Catarina", "São Paulo", "Sergipe", "Tocantins"};
    private int[] qtdConfirmadosPorEstados = {6708, 1838, 509, 1291,341,4324,424,3442,32423,4324,645,765,345,675,234,765,325,5674,25453,567567,8768,345354,4564,456,564,34,34};
    private int[] qtdSuspeitos ={6708, 1838, 509, 1291,341,4324,424,3442,32423,4324,645,765,345,675,234,765,325,5674,25453,567567,8768,345354,4564,456,564,34,45};
    private int[] qtdObitos ={6708, 1838, 509, 1291,341,4324,424,3442,32423,4324,645,765,345,675,234,765,325,5674,25453,567567,8768,345354,4564,456,564,34,54};
    private int[] qtdDescartados = {6708, 1838, 509, 1291,341,4324,424,3442,32423,4324,645,765,345,675,234,765,325,5674,25453,567567,8768,345354,4564,456,564,34,34};
    private int[] qtdRecuperados = {6708, 1838, 509, 1291,341,4324,424,3442,32423,4324,645,765,345,675,234,765,325,5674,25453,567567,8768,345354,4564,456,564,34,432};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_estados);

        lista = findViewById(R.id.listaEstados);

        ArrayAdapter<String> adaptador = new ArrayAdapter<>(
                getApplicationContext(), android.R.layout.simple_list_item_1, android.R.id.text1, listaEstados
        );

        lista.setAdapter(adaptador);

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(),qtdConfirmadosPorEstados[position]+"casos confirmados", Toast.LENGTH_SHORT).show();

            }
        });

        lista.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                dialog = new AlertDialog.Builder(Estados.this);
                String mensagem = "";

                mensagem +="Confirmados: "+qtdConfirmadosPorEstados[position];
                mensagem +="\nSuspeitos: "+qtdSuspeitos[position];
                mensagem +="\nObitos: "+qtdObitos[position];
                mensagem +="\nDescartados: "+qtdDescartados[position];
                mensagem +="\nRecuperados: "+qtdRecuperados[position];

                dialog.setTitle("Covid-19 no estado: " + listaEstados[position]);
                dialog.setMessage(mensagem);
                dialog.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                dialog.setIcon(android.R.drawable.star_big_on);
                dialog.create();
                dialog.show();

                return true;
            }
        });
    }
}
