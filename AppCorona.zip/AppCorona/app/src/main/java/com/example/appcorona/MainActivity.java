package com.example.appcorona;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private Button botaoEntrar;
    private EditText txtUsuario;
    private EditText txtSenha;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtUsuario = findViewById(R.id.txtUsuario);
        txtSenha = findViewById(R.id.txtsenha);
        botaoEntrar = findViewById(R.id.btEntrar);



        botaoEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(MainActivity.this, SegundaTela.class);
                intent.putExtra("nome", txtUsuario.getText().toString());
                intent.putExtra("senha", txtSenha.getText().toString());

                startActivity(intent);
            }
        });

        }

    }

