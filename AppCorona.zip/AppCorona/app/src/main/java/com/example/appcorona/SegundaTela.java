package com.example.appcorona;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SegundaTela extends AppCompatActivity {

    private Button btEstados;
    private TextView txtSenha;
    private TextView txtUsuario;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda_tela);

        txtSenha = findViewById(R.id.txtPass);
        txtUsuario = findViewById(R.id.txtUser);
        btEstados = findViewById(R.id.btEstados);

        Bundle extras = getIntent().getExtras();

        if(extras != null){
            txtUsuario.setText( extras.getString("nome"));
            txtSenha.setText(extras.getString("senha"));

        }

        btEstados.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SegundaTela.this, Estados.class));

            }
        });
    }
}
